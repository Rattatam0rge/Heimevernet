namespace FeedbackMap.Services;

public record NearbyResource(ResourceListItem Resource, double DistanceMeters, bool TypeMatches);

public record AssignmentView(int Id, int ResourceId, string ResourceType, string? Phone, string? Email,
    DateTime AssignedAt, DateTime? UnassignedAt, FeedbackMap.Models.MatchStatus Status, bool IsActive);

public interface IAssignmentService
{
    /// <summary>Tilgjengelige ressurser innenfor radius (meter), sortert på avstand.</summary>
    Task<IReadOnlyList<NearbyResource>> FindNearbyAsync(int needId, double radiusMeters, bool onlySuitableTypes);

    Task<ServiceResult> AssignAsync(int needId, int resourceId, string userId);
    Task<ServiceResult> UnassignAsync(int assignmentId, string userId);
    Task<IReadOnlyList<AssignmentView>> ListForNeedAsync(int needId);
}
