namespace FeedbackMap.Services;

public record NotificationItem(int Id, string Message, DateTime CreatedAt, bool IsRead);

public interface INotificationService
{
    Task<IReadOnlyList<NotificationItem>> ListAsync(string providerId, int take = 100);
    Task<int> UnreadCountAsync(string providerId);
    Task<bool> MarkReadAsync(string providerId, int notificationId);
    Task MarkAllReadAsync(string providerId);
}
