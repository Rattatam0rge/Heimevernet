using FeedbackMap.Models;

namespace FeedbackMap.Services;

public record NeedInput(string Type, string? Description, decimal Latitude, decimal Longitude,
    DateTime Deadline, NeedPriority Priority, string ContactPoint);

public record NeedListItem(int Id, string Type, NeedPriority Priority, NeedStatus Status, DateTime Deadline,
    string Organisation, decimal Latitude, decimal Longitude, string ContactPoint);

public record StatusHistoryItem(NeedStatus Status, DateTime ChangedAt, string ChangedBy);

public record NeedDetails(int Id, string Type, string? Description, NeedPriority Priority, NeedStatus Status,
    DateTime Deadline, string ContactPoint, decimal Latitude, decimal Longitude, string Organisation,
    DateTime CreatedAt, IReadOnlyList<StatusHistoryItem> History, IReadOnlyList<NeedStatus> NextStatuses);

public interface INeedService
{
    Task<int> CreateAsync(string userId, NeedInput input);
    Task<IReadOnlyList<NeedListItem>> ListAsync(bool includeResolved);
    Task<NeedDetails?> GetDetailsAsync(int id);
    Task<ServiceResult> ChangeStatusAsync(int id, NeedStatus newStatus, string userId);
}
