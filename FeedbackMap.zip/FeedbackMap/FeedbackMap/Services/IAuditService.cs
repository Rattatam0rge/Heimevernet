namespace FeedbackMap.Services;

public record AuditItem(int Id, DateTime Timestamp, string? User, string Action, string EntityType,
    string? EntityId, string? Details);

public interface IAuditService
{
    /// <summary>Legger til en loggrad i samme DbContext. Lagres sammen med neste SaveChanges.</summary>
    void Add(string? userId, string action, string entityType, string? entityId = null, string? details = null);

    /// <summary>Legger til og lagrer umiddelbart.</summary>
    Task LogAsync(string? userId, string action, string entityType, string? entityId = null, string? details = null);

    Task<IReadOnlyList<AuditItem>> ListRecentAsync(int take = 200);
}
