namespace FeedbackMap.Services;

public record ActorBase(string UserId, string Organisation, string? RoleTitle, string? Label,
    decimal Latitude, decimal Longitude, string? Email);

public interface IActorService
{
    Task<ServiceResult> SetBaseAsync(string userId, decimal latitude, decimal longitude, string? label);
    Task<IReadOnlyList<ActorBase>> ListBasesAsync();
}
