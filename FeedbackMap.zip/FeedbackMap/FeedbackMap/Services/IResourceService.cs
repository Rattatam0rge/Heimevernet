using FeedbackMap.Models;

namespace FeedbackMap.Services;

public record ResourceInput(string Type, string? Description, decimal Latitude, decimal Longitude,
    DateTime AvailableFrom, DateTime? AvailableTo, string? ImageFileName = null);

public record ResourceListItem(int Id, string Type, string? Description, decimal Latitude, decimal Longitude,
    DateTime AvailableFrom, DateTime? AvailableTo, ResourceStatus Status, ProviderType ProviderType,
    string? Phone, string? Email, bool HasImage, bool IsAssigned);

public record ResourceImageInfo(string OwnerId, string FileName);

public interface IResourceService
{
    Task<int> CreateAsync(string userId, ResourceInput input);
    Task<IReadOnlyList<ResourceListItem>> ListForProviderAsync(string userId);
    Task<IReadOnlyList<ResourceListItem>> ListAvailableAsync();
    Task<IReadOnlyList<ResourceListItem>> ListInBoundsAsync(decimal minLat, decimal maxLat, decimal minLng, decimal maxLng, string? type);
    Task<ResourceImageInfo?> GetImageAsync(int id);
    Task<ServiceResult> RemoveAsync(string userId, int id);
}
