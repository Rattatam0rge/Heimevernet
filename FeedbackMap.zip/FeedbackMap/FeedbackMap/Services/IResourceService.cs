using FeedbackMap.Models;

namespace FeedbackMap.Services;

public record ResourceInput(string Type, string? Description, decimal Latitude, decimal Longitude,
    DateTime AvailableFrom, DateTime? AvailableTo);

public record ResourceListItem(int Id, string Type, string? Description, decimal Latitude, decimal Longitude,
    DateTime AvailableFrom, DateTime? AvailableTo, ResourceStatus Status, ProviderType ProviderType,
    string? Phone, string? Email);

public interface IResourceService
{
    Task<int> CreateAsync(string userId, ResourceInput input);
    Task<IReadOnlyList<ResourceListItem>> ListForProviderAsync(string userId);
    Task<IReadOnlyList<ResourceListItem>> ListAvailableAsync();
    Task<ServiceResult> RemoveAsync(string userId, int id);
}
