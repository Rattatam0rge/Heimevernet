using FeedbackMap.Data;
using FeedbackMap.Models;
using Microsoft.EntityFrameworkCore;

namespace FeedbackMap.Services;

public class ResourceService : IResourceService
{
    private readonly ApplicationDbContext _db;

    public ResourceService(ApplicationDbContext db) => _db = db;

    public async Task<int> CreateAsync(string userId, ResourceInput input)
    {
        var resource = new Resource
        {
            ResourceProviderId = userId,
            Type = input.Type,
            Description = string.IsNullOrWhiteSpace(input.Description) ? null : input.Description.Trim(),
            Latitude = input.Latitude,
            Longitude = input.Longitude,
            AvailableFrom = input.AvailableFrom,
            AvailableTo = input.AvailableTo,
            Status = ResourceStatus.Available,
            IsActive = true
        };
        _db.Resources.Add(resource);
        await _db.SaveChangesAsync();
        return resource.Id;
    }

    public async Task<IReadOnlyList<ResourceListItem>> ListForProviderAsync(string userId)
    {
        var list = await Query()
            .Where(r => r.ResourceProviderId == userId && r.IsActive)
            .OrderBy(r => r.Type)
            .ToListAsync();
        return list.Select(ToItem).ToList();
    }

    public async Task<IReadOnlyList<ResourceListItem>> ListAvailableAsync()
    {
        var now = DateTime.UtcNow;
        var list = await Query()
            .Where(r => r.IsActive
                        && r.Status == ResourceStatus.Available
                        && (r.AvailableTo == null || r.AvailableTo >= now))
            .OrderBy(r => r.Type)
            .ToListAsync();
        return list.Select(ToItem).ToList();
    }

    public async Task<ServiceResult> RemoveAsync(string userId, int id)
    {
        var resource = await _db.Resources.Include(r => r.Assignments)
            .FirstOrDefaultAsync(r => r.Id == id && r.IsActive);
        if (resource is null) return ServiceResult.Fail("Fant ikke ressursen.");
        if (resource.ResourceProviderId != userId) return ServiceResult.Deny();

        if (resource.Assignments.Count > 0)
        {
            // Har historikk: behold raden slik at tidligere tildelinger ikke forsvinner
            resource.IsActive = false;
            resource.Status = ResourceStatus.Unavailable;
            await _db.SaveChangesAsync();
            return ServiceResult.Ok("Ressursen er fjernet fra listen. Historikken er beholdt.");
        }

        _db.Resources.Remove(resource);
        await _db.SaveChangesAsync();
        return ServiceResult.Ok("Ressursen er slettet.");
    }

    private IQueryable<Resource> Query() =>
        _db.Resources.AsNoTracking()
            .Include(r => r.ResourceProvider).ThenInclude(p => p.User);

    private static ResourceListItem ToItem(Resource r) =>
        new(r.Id, r.Type, r.Description, r.Latitude, r.Longitude, r.AvailableFrom, r.AvailableTo, r.Status,
            r.ResourceProvider.ProviderType, r.ResourceProvider.ContactPhone, r.ResourceProvider.User.Email);
}
