using Microsoft.AspNetCore.Http;

namespace FeedbackMap.Services;

public class StorageOptions
{
    public const string SectionName = "Storage";

    /// <summary>Mappe for opplastede bilder. Tom = «uploads» ved siden av applikasjonen.</summary>
    public string? UploadsPath { get; set; }
}

public record ImageSaveResult(bool Success, string? FileName, string? Error);

public interface IImageStorage
{
    Task<ImageSaveResult> SaveAsync(IFormFile file, CancellationToken ct = default);
    Stream? Open(string fileName);
    void Delete(string fileName);
    string ContentTypeFor(string fileName);
}
