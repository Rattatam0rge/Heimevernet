namespace FeedbackMap.Services;

public record ServiceResult(bool Success, string Message, bool Forbidden = false)
{
    public static ServiceResult Ok(string message) => new(true, message);
    public static ServiceResult Fail(string message) => new(false, message);
    public static ServiceResult Deny() => new(false, "Du har ikke tilgang til dette.", true);
}
