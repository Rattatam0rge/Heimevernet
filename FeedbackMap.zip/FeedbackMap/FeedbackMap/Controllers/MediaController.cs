using System.Security.Claims;
using FeedbackMap.Models;
using FeedbackMap.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FeedbackMap.Controllers;

/// <summary>Leverer ressursbilder. Bare innloggede (med 2FA) får se dem. Leverandører ser kun egne bilder.</summary>
[Authorize(Policy = Policies.RequireMfa)]
public class MediaController : Controller
{
    private readonly IResourceService _resources;
    private readonly IImageStorage _images;

    public MediaController(IResourceService resources, IImageStorage images)
    {
        _resources = resources;
        _images = images;
    }

    [HttpGet]
    public async Task<IActionResult> ResourceImage(int id)
    {
        var info = await _resources.GetImageAsync(id);
        if (info is null) return NotFound();

        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (User.IsInRole(Roles.ResourceProvider) && info.OwnerId != userId) return Forbid();

        var stream = _images.Open(info.FileName);
        if (stream is null) return NotFound();

        Response.Headers["X-Content-Type-Options"] = "nosniff";
        Response.Headers["Cache-Control"] = "private, max-age=3600";
        return File(stream, _images.ContentTypeFor(info.FileName));
    }
}
