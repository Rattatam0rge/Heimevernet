using System.Security.Claims;
using FeedbackMap.Data;
using FeedbackMap.Models;
using FeedbackMap.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QRCoder;

namespace FeedbackMap.Controllers;

public class AccountController : Controller
{
    private const string AppName = "FeedbackMap";

    private readonly UserManager<ApplicationUser> _users;
    private readonly SignInManager<ApplicationUser> _signIn;
    private readonly ApplicationDbContext _db;
    private readonly ILogger<AccountController> _logger;

    public AccountController(
        UserManager<ApplicationUser> users,
        SignInManager<ApplicationUser> signIn,
        ApplicationDbContext db,
        ILogger<AccountController> logger)
    {
        _users = users;
        _signIn = signIn;
        _db = db;
        _logger = logger;
    }

    // ---------- Registrering ----------

    [HttpGet, AllowAnonymous]
    public IActionResult Register() => View(new RegisterViewModel());

    [HttpPost, AllowAnonymous]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = new ApplicationUser { UserName = model.Email, Email = model.Email };
        var result = await _users.CreateAsync(user, model.Password);
        if (!result.Succeeded)
        {
            foreach (var msg in result.Errors.Select(e => e.Description).Distinct()) ModelState.AddModelError(string.Empty, msg);
            return View(model);
        }

        try
        {
            await _users.AddToRoleAsync(user, model.Role);

            if (model.Role == Roles.PublicActor)
            {
                _db.PublicActorProfiles.Add(new PublicActorProfile
                {
                    UserId = user.Id,
                    Organisation = model.Organisation!.Trim(),
                    RoleTitle = model.RoleTitle?.Trim()
                });
            }
            else
            {
                _db.ResourceProviderProfiles.Add(new ResourceProviderProfile
                {
                    UserId = user.Id,
                    ProviderType = model.ProviderType!.Value,
                    ContactPhone = model.ContactPhone?.Trim()
                });
            }
            await _db.SaveChangesAsync();
        }
        catch
        {
            await _users.DeleteAsync(user);   // ingen halvferdige brukere
            throw;
        }

        _logger.LogInformation("Ny bruker registrert med rolle {Role}", model.Role);

        // Innlogget, men uten 2FA ennå -> må sette opp authenticator før tilgang til resten
        await _signIn.SignInAsync(user, isPersistent: false);
        return RedirectToAction(nameof(EnableAuthenticator));
    }

    // ---------- Innlogging ----------

    [HttpGet, AllowAnonymous]
    public IActionResult Login(string? returnUrl = null) => View(new LoginViewModel { ReturnUrl = returnUrl });

    [HttpPost, AllowAnonymous]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var result = await _signIn.PasswordSignInAsync(
            model.Email, model.Password, model.RememberMe, lockoutOnFailure: true);

        if (result.RequiresTwoFactor)
            return RedirectToAction(nameof(LoginWith2fa), new { rememberMe = model.RememberMe, returnUrl = model.ReturnUrl });

        if (result.IsLockedOut)
            return View("Lockout");

        if (result.Succeeded)
        {
            // Bruker uten 2FA: innlogget, men sendes til oppsett (2FA er påkrevd)
            return RedirectToAction(nameof(EnableAuthenticator));
        }

        ModelState.AddModelError(string.Empty, "Feil e-post eller passord.");
        return View(model);
    }

    [HttpGet, AllowAnonymous]
    public async Task<IActionResult> LoginWith2fa(bool rememberMe, string? returnUrl = null)
    {
        var user = await _signIn.GetTwoFactorAuthenticationUserAsync();
        if (user is null) return RedirectToAction(nameof(Login));
        return View(new LoginWith2faViewModel { RememberMe = rememberMe, ReturnUrl = returnUrl });
    }

    [HttpPost, AllowAnonymous]
    public async Task<IActionResult> LoginWith2fa(LoginWith2faViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = await _signIn.GetTwoFactorAuthenticationUserAsync();
        if (user is null) return RedirectToAction(nameof(Login));

        var code = model.Code.Replace(" ", string.Empty).Replace("-", string.Empty);
        var result = await _signIn.TwoFactorAuthenticatorSignInAsync(
            code, model.RememberMe, rememberClient: false);

        if (result.Succeeded) return RedirectToLocal(model.ReturnUrl);
        if (result.IsLockedOut) return View("Lockout");

        ModelState.AddModelError(nameof(model.Code), "Ugyldig kode.");
        return View(model);
    }

    [HttpGet, AllowAnonymous]
    public async Task<IActionResult> LoginWithRecoveryCode(string? returnUrl = null)
    {
        var user = await _signIn.GetTwoFactorAuthenticationUserAsync();
        if (user is null) return RedirectToAction(nameof(Login));
        return View(new LoginWithRecoveryCodeViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost, AllowAnonymous]
    public async Task<IActionResult> LoginWithRecoveryCode(LoginWithRecoveryCodeViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = await _signIn.GetTwoFactorAuthenticationUserAsync();
        if (user is null) return RedirectToAction(nameof(Login));

        var code = model.RecoveryCode.Replace(" ", string.Empty);
        var result = await _signIn.TwoFactorRecoveryCodeSignInAsync(code);

        if (result.Succeeded) return RedirectToLocal(model.ReturnUrl);
        if (result.IsLockedOut) return View("Lockout");

        ModelState.AddModelError(nameof(model.RecoveryCode), "Ugyldig gjenopprettingskode.");
        return View(model);
    }

    [HttpPost, Authorize]
    public async Task<IActionResult> Logout()
    {
        await _signIn.SignOutAsync();
        return RedirectToAction("Index", "Home");
    }

    [HttpGet, AllowAnonymous]
    public IActionResult AccessDenied() => View();

    // ---------- 2FA-oppsett (TOTP) ----------

    [HttpGet, Authorize]
    public async Task<IActionResult> EnableAuthenticator()
    {
        var user = await _users.GetUserAsync(User);
        if (user is null) return RedirectToAction(nameof(Login));
        if (user.TwoFactorEnabled) return RedirectToAction(nameof(Manage));

        return View(await BuildAuthenticatorModelAsync(user, string.Empty));
    }

    [HttpPost, Authorize]
    public async Task<IActionResult> EnableAuthenticator(EnableAuthenticatorViewModel model)
    {
        var user = await _users.GetUserAsync(User);
        if (user is null) return RedirectToAction(nameof(Login));
        if (user.TwoFactorEnabled) return RedirectToAction(nameof(Manage));

        if (ModelState.IsValid)
        {
            var code = model.Code.Replace(" ", string.Empty).Replace("-", string.Empty);
            var valid = await _users.VerifyTwoFactorTokenAsync(
                user, _users.Options.Tokens.AuthenticatorTokenProvider, code);

            if (valid)
            {
                await _users.SetTwoFactorEnabledAsync(user, true);
                var recoveryCodes = await _users.GenerateNewTwoFactorRecoveryCodesAsync(user, 10);

                // Ny cookie med amr=mfa, slik at policyen RequireMfa slipper brukeren gjennom
                await _signIn.SignInWithClaimsAsync(user, false, new[] { new Claim("amr", "mfa") });

                _logger.LogInformation("2FA aktivert for bruker {UserId}", user.Id);
                return View("RecoveryCodes", recoveryCodes!.ToArray());
            }

            ModelState.AddModelError(nameof(model.Code), "Ugyldig kode. Prøv igjen.");
        }

        return View(await BuildAuthenticatorModelAsync(user, string.Empty));
    }

    // ---------- Min side ----------

    [HttpGet, Authorize(Policy = Policies.RequireMfa)]
    public async Task<IActionResult> Manage()
    {
        var user = await _users.GetUserAsync(User);
        if (user is null) return RedirectToAction(nameof(Login));

        var profile = await _db.PublicActorProfiles.AsNoTracking()
            .FirstOrDefaultAsync(p => p.UserId == user.Id);

        return View(new ManageViewModel
        {
            Email = user.Email ?? string.Empty,
            Roles = await _users.GetRolesAsync(user),
            TwoFactorEnabled = user.TwoFactorEnabled,
            Organisation = profile?.Organisation
        });
    }

    // ---------- Hjelpere ----------

    private IActionResult RedirectToLocal(string? returnUrl) =>
        !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? LocalRedirect(returnUrl)
            : RedirectToAction("Index", "Home");

    private async Task<EnableAuthenticatorViewModel> BuildAuthenticatorModelAsync(ApplicationUser user, string code)
    {
        var key = await _users.GetAuthenticatorKeyAsync(user);
        if (string.IsNullOrEmpty(key))
        {
            await _users.ResetAuthenticatorKeyAsync(user);
            key = await _users.GetAuthenticatorKeyAsync(user);
        }

        var email = user.Email ?? user.UserName ?? "bruker";
        var uri = $"otpauth://totp/{Uri.EscapeDataString(AppName)}:{Uri.EscapeDataString(email)}" +
                  $"?secret={key}&issuer={Uri.EscapeDataString(AppName)}&digits=6";

        var generator = new QRCodeGenerator();
        var qrData = generator.CreateQrCode(uri, QRCodeGenerator.ECCLevel.Q);
        var png = new PngByteQRCode(qrData).GetGraphic(6);

        return new EnableAuthenticatorViewModel
        {
            Code = code,
            SharedKey = FormatKey(key!),
            QrCodeDataUri = "data:image/png;base64," + Convert.ToBase64String(png)
        };
    }

    private static string FormatKey(string key)
    {
        var parts = new List<string>();
        for (var i = 0; i < key.Length; i += 4)
            parts.Add(key.Substring(i, Math.Min(4, key.Length - i)));
        return string.Join(" ", parts).ToLowerInvariant();
    }
}
