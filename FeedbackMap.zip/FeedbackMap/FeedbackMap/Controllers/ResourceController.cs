using System.Security.Claims;
using FeedbackMap.Models;
using FeedbackMap.Services;
using FeedbackMap.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FeedbackMap.Controllers;

[Authorize(Policy = Policies.RequireMfa)]
public class ResourceController : Controller
{
    private readonly IResourceService _resources;
    private readonly IImageStorage _images;

    public ResourceController(IResourceService resources, IImageStorage images)
    {
        _resources = resources;
        _images = images;
    }

    private string UserId => User.FindFirstValue(ClaimTypes.NameIdentifier)!;

    // Leverandør ser egne ressurser, offentlig aktør ser tilgjengelige ressurser
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var isProvider = User.IsInRole(Roles.ResourceProvider);
        var items = isProvider
            ? await _resources.ListForProviderAsync(UserId)
            : await _resources.ListAvailableAsync();

        return View(new ResourceIndexViewModel { IsProvider = isProvider, Items = items });
    }

    // Utskriftsvennlig ressursliste for en region (kartutsnitt) – case: «skrive ut ressurslister for sin region»
    [HttpGet, Authorize(Roles = Roles.PublicActor)]
    public async Task<IActionResult> Print(decimal? minLat, decimal? maxLat, decimal? minLng, decimal? maxLng, string? type)
    {
        var hasBounds = minLat.HasValue && maxLat.HasValue && minLng.HasValue && maxLng.HasValue;
        var items = hasBounds
            ? await _resources.ListInBoundsAsync(minLat!.Value, maxLat!.Value, minLng!.Value, maxLng!.Value, type)
            : (await _resources.ListAvailableAsync()).Where(r => string.IsNullOrWhiteSpace(type) || r.Type == type).ToList();

        return View(new ResourcePrintViewModel
        {
            Items = items,
            Type = type,
            HasBounds = hasBounds,
            MinLat = minLat ?? 0, MaxLat = maxLat ?? 0, MinLng = minLng ?? 0, MaxLng = maxLng ?? 0
        });
    }

    // Registrering skjer i panelet på kartsiden
    [HttpGet, Authorize(Roles = Roles.ResourceProvider)]
    public IActionResult Create() => Redirect("/?register=1");

    /// <summary>Kalles fra registrer-panelet på kartet (fetch, multipart). Svarer med JSON.</summary>
    [HttpPost, Authorize(Roles = Roles.ResourceProvider), RequestSizeLimit(8_000_000)]
    public async Task<IActionResult> Create(ResourceCreateViewModel model)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState
                .Where(e => e.Value is { Errors.Count: > 0 })
                .ToDictionary(e => e.Key, e => e.Value!.Errors.Select(x => x.ErrorMessage).ToArray());
            return BadRequest(new { success = false, errors });
        }

        string? imageName = null;
        if (model.Image is { Length: > 0 })
        {
            var saved = await _images.SaveAsync(model.Image);
            if (!saved.Success)
            {
                var errors = new Dictionary<string, string[]> { ["Image"] = new[] { saved.Error! } };
                return BadRequest(new { success = false, errors });
            }
            imageName = saved.FileName;
        }

        int id;
        try
        {
            id = await _resources.CreateAsync(UserId, new ResourceInput(
                model.Type, model.Description, model.Latitude!.Value, model.Longitude!.Value,
                model.AvailableFrom!.Value, model.AvailableTo, imageName));
        }
        catch
        {
            if (imageName is not null) _images.Delete(imageName);   // ikke la bildet bli liggende uten ressurs
            throw;
        }

        return Ok(new
        {
            success = true,
            id,
            message = "Ressursen er registrert.",
            url = Url.Action(nameof(Index)),
            linkText = "Se mine ressurser",
            lat = model.Latitude,
            lng = model.Longitude
        });
    }

    [HttpPost, Authorize(Roles = Roles.ResourceProvider)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _resources.RemoveAsync(UserId, id);
        if (result.Forbidden) return Forbid();

        TempData[result.Success ? "Success" : "Error"] = result.Message;
        return RedirectToAction(nameof(Index));
    }
}
