using System.Security.Claims;
using FeedbackMap.Models;
using FeedbackMap.Services;
using FeedbackMap.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FeedbackMap.Controllers;

[Authorize(Policy = Policies.RequireMfa)]
public class ResourceController : Controller
{
    private readonly IResourceService _resources;

    public ResourceController(IResourceService resources) => _resources = resources;

    private string UserId => User.FindFirstValue(ClaimTypes.NameIdentifier)!;

    // Leverandør ser egne ressurser, offentlig aktør ser tilgjengelige ressurser
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var isProvider = User.IsInRole(Roles.ResourceProvider);
        var items = isProvider
            ? await _resources.ListForProviderAsync(UserId)
            : await _resources.ListAvailableAsync();

        return View(new ResourceIndexViewModel { IsProvider = isProvider, Items = items });
    }

    // Registrering skjer i panelet på kartsiden
    [HttpGet, Authorize(Roles = Roles.ResourceProvider)]
    public IActionResult Create() => Redirect("/?register=1");

    /// <summary>Kalles fra registrer-panelet på kartet (fetch). Svarer med JSON.</summary>
    [HttpPost, Authorize(Roles = Roles.ResourceProvider)]
    public async Task<IActionResult> Create(ResourceCreateViewModel model)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState
                .Where(e => e.Value is { Errors.Count: > 0 })
                .ToDictionary(e => e.Key, e => e.Value!.Errors.Select(x => x.ErrorMessage).ToArray());
            return BadRequest(new { success = false, errors });
        }

        var id = await _resources.CreateAsync(UserId, new ResourceInput(
            model.Type, model.Description, model.Latitude!.Value, model.Longitude!.Value,
            model.AvailableFrom!.Value, model.AvailableTo));

        return Ok(new
        {
            success = true,
            id,
            message = "Ressursen er registrert.",
            url = Url.Action(nameof(Index)),
            linkText = "Se mine ressurser",
            lat = model.Latitude,
            lng = model.Longitude
        });
    }

    [HttpPost, Authorize(Roles = Roles.ResourceProvider)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _resources.RemoveAsync(UserId, id);
        if (result.Forbidden) return Forbid();

        TempData[result.Success ? "Success" : "Error"] = result.Message;
        return RedirectToAction(nameof(Index));
    }
}
