using System.Diagnostics;
using FeedbackMap.Models;
using Microsoft.AspNetCore.Mvc;

namespace FeedbackMap.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        // Innlogget uten fullført 2FA -> må fullføre oppsettet først
        if (User.Identity?.IsAuthenticated == true && !User.HasClaim("amr", "mfa"))
            return RedirectToAction("EnableAuthenticator", "Account");

        return View();
    }

    public IActionResult Privacy() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() =>
        View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
}
