using System.Diagnostics;
using FeedbackMap.Models;
using FeedbackMap.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace FeedbackMap.Controllers;

public class HomeController : Controller
{
    private readonly SecurityOptions _security;

    public HomeController(IOptions<SecurityOptions> security) => _security = security.Value;

    public IActionResult Index()
    {
        // Innlogget uten fullført 2FA -> må fullføre oppsettet først (bare når 2FA er påkrevd)
        if (_security.RequireTwoFactor && User.Identity?.IsAuthenticated == true && !User.HasClaim("amr", "mfa"))
            return RedirectToAction("EnableAuthenticator", "Account");

        return View();
    }

    public IActionResult Privacy() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() =>
        View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
}
