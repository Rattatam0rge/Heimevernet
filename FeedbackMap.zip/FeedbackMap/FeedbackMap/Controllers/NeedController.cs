using System.Security.Claims;
using FeedbackMap.Models;
using FeedbackMap.Services;
using FeedbackMap.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FeedbackMap.Controllers;

[Authorize(Policy = Policies.RequireMfa, Roles = Roles.PublicActor)]
public class NeedController : Controller
{
    private readonly INeedService _needs;

    public NeedController(INeedService needs) => _needs = needs;

    private string UserId => User.FindFirstValue(ClaimTypes.NameIdentifier)!;

    [HttpGet]
    public async Task<IActionResult> Index(bool showResolved = false)
    {
        ViewData["ShowResolved"] = showResolved;
        return View(await _needs.ListAsync(showResolved));
    }

    // Registrering skjer i panelet på kartsiden
    [HttpGet]
    public IActionResult Create() => Redirect("/?register=1");

    /// <summary>Kalles fra registrer-panelet på kartet (fetch). Svarer med JSON.</summary>
    [HttpPost]
    public async Task<IActionResult> Create(NeedCreateViewModel model)
    {
        if (!ModelState.IsValid)
        {
            var errors = ModelState
                .Where(e => e.Value is { Errors.Count: > 0 })
                .ToDictionary(e => e.Key, e => e.Value!.Errors.Select(x => x.ErrorMessage).ToArray());
            return BadRequest(new { success = false, errors });
        }

        var id = await _needs.CreateAsync(UserId, new NeedInput(
            model.Type, model.Description, model.Latitude!.Value, model.Longitude!.Value,
            model.Deadline!.Value, model.Priority, model.ContactPoint));

        return Ok(new
        {
            success = true,
            id,
            message = "Behovet er registrert.",
            url = Url.Action(nameof(Details), new { id }),
            linkText = "Åpne behov",
            lat = model.Latitude,
            lng = model.Longitude
        });
    }

    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var details = await _needs.GetDetailsAsync(id);
        return details is null ? NotFound() : View(details);
    }

    [HttpPost]
    public async Task<IActionResult> ChangeStatus(int id, NeedStatus status)
    {
        var result = await _needs.ChangeStatusAsync(id, status, UserId);
        TempData[result.Success ? "Success" : "Error"] = result.Message;
        return RedirectToAction(nameof(Details), new { id });
    }
}
