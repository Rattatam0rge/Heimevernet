(function () {
  'use strict';

  var mapEl = document.getElementById('map');
  if (!mapEl) return;

  var map = L.map('map').setView(FM.NORWAY, 5);
  var base = FM.addBaseLayers(map);
  FM.map = map;

  var layer = L.layerGroup().addTo(map);
  var all = [];
  var firstLoad = true;
  var state = { acute: true, planned: true, resource: true, actor: true, type: '' };

  var statusEl = document.getElementById('map-status');
  var typeSelect = document.getElementById('f-type');

  // ---- Tegnforklaring: åpen som standard, kan minimeres med streken ----
  var legendBox = document.getElementById('legend-box');
  var legend = document.getElementById('legend');
  var legendToggle = document.getElementById('legend-toggle');

  var KIND_LABELS = {
    acute: 'Akutt behov', planned: 'Planlagt behov',
    resource: 'Tilgjengelig ressurs', actor: 'Offentlig aktør'
  };
  var kindsBox = document.getElementById('legend-kinds');
  (legendBox.dataset.kinds || 'resource').split(',').forEach(function (k) {
    var row = document.createElement('div');
    row.className = 'legend-item';
    var ic = document.createElement('span');
    ic.innerHTML = FM.markerSvg(k, null, 30);
    var label = document.createElement('span');
    label.textContent = KIND_LABELS[k];
    row.append(ic, label);
    kindsBox.append(row);
  });

  // Typer som finnes på kartet akkurat nå, med samme symbol som i markøren
  var typesWrap = document.getElementById('legend-types-wrap');
  var typesBox = document.getElementById('legend-types');
  function renderTypeLegend() {
    var types = Array.from(new Set(all
      .filter(function (m) { return m.kind !== 'actor'; })
      .map(function (m) { return m.type; }))).sort();
    typesBox.textContent = '';
    types.forEach(function (t) {
      var row = document.createElement('div');
      row.className = 'legend-item';
      var ic = document.createElement('span');
      ic.innerHTML = FM.typeIconSvg(t);
      var label = document.createElement('span');
      label.textContent = t;
      row.append(ic, label);
      typesBox.append(row);
    });
    typesWrap.hidden = types.length === 0;
  }

  function setLegend(open) {
    legend.hidden = !open;
    legendBox.classList.toggle('minimized', !open);
    legendToggle.setAttribute('aria-expanded', String(open));
    legendToggle.setAttribute('aria-label', open ? 'Minimer tegnforklaring' : 'Åpne tegnforklaring');
    try { localStorage.setItem('fm.legend', open ? 'open' : 'min'); } catch (e) { /* ignorer */ }
  }
  var savedLegend = null;
  try { savedLegend = localStorage.getItem('fm.legend'); } catch (e) { /* ignorer */ }
  setLegend(savedLegend !== 'min');
  legendToggle.addEventListener('click', function () { setLegend(legend.hidden); });

  // ---- Popup (bygges med DOM/textContent: brukerdata tolkes aldri som HTML) ----
  function row(label, value) {
    var d = document.createElement('div');
    var l = document.createElement('span');
    l.className = 'text-body-secondary';
    l.textContent = label + ': ';
    var v = document.createElement('span');
    v.textContent = value;
    d.append(l, v);
    return d;
  }

  function linkRow(label, text, href) {
    var d = document.createElement('div');
    var l = document.createElement('span');
    l.className = 'text-body-secondary';
    l.textContent = label + ': ';
    var a = document.createElement('a');
    a.textContent = text;
    a.href = href;
    d.append(l, a);
    return d;
  }

  function buildPopup(m) {
    var root = document.createElement('div');
    var h = document.createElement('strong');
    h.textContent = m.title;
    root.append(h);
    if (m.status) root.append(row('Status', m.status));
    if (m.when) root.append(row('Tid', m.when));
    if (m.contact) root.append(row('Kontakt', m.contact));
    if (m.phone) root.append(linkRow('Telefon', m.phone, 'tel:' + m.phone.replace(/[^+0-9]/g, '')));
    if (m.email) root.append(linkRow('E-post', m.email, 'mailto:' + m.email));
    if (m.url) {
      var a = document.createElement('a');
      a.className = 'btn btn-primary btn-sm mt-2 text-white';
      a.href = m.url;
      a.textContent = 'Åpne detaljer';
      root.append(a);
    }
    return root;
  }

  // ---- Filter ----
  function visible(m) {
    return state[m.icon] && (!state.type || m.type === state.type);
  }

  function render() {
    layer.clearLayers();
    var shown = all.filter(visible);
    shown.forEach(function (m) {
      var marker = L.marker([m.lat, m.lng], { icon: FM.icon(m.icon, m.type), title: m.title, alt: m.title, keyboard: true });
      marker.bindPopup(buildPopup(m));
      layer.addLayer(marker);
    });
    var needs = shown.filter(function (m) { return m.kind === 'need'; }).length;
    statusEl.textContent = needs + ' behov og ' + (shown.length - needs) + ' ressurser vises';
  }

  function refreshTypeOptions() {
    var types = Array.from(new Set(all.map(function (m) { return m.type; }))).sort();
    var current = state.type;
    typeSelect.length = 1;
    types.forEach(function (t) {
      var o = document.createElement('option');
      o.value = t;
      o.textContent = t;
      typeSelect.append(o);
    });
    typeSelect.value = types.indexOf(current) >= 0 ? current : '';
    state.type = typeSelect.value;
  }

  var toggle = document.getElementById('filter-toggle');
  var panel = document.getElementById('filter-panel');
  toggle.addEventListener('click', function () {
    var open = panel.hidden;
    panel.hidden = !open;
    toggle.setAttribute('aria-expanded', String(open));
  });

  ['acute', 'planned', 'resource', 'actor'].forEach(function (k) {
    var el = document.getElementById('f-' + k);
    if (el) el.addEventListener('change', function (e) { state[k] = e.target.checked; render(); });
  });
  typeSelect.addEventListener('change', function () { state.type = typeSelect.value; render(); });

  // Flyfoto: av som standard, kan slås av og på
  var aerialToggle = document.getElementById('f-aerial');
  function setAerial(on) {
    aerialToggle.checked = on;
    if (on) base.aerial.addTo(map); else map.removeLayer(base.aerial);
  }
  aerialToggle.addEventListener('change', function (e) { setAerial(e.target.checked); });

  document.getElementById('f-reset').addEventListener('click', function () {
    state.acute = state.planned = state.resource = state.actor = true;
    state.type = '';
    ['acute', 'planned', 'resource', 'actor'].forEach(function (k) {
      var el = document.getElementById('f-' + k);
      if (el) el.checked = true;
    });
    typeSelect.value = '';
    setAerial(false);
    render();
  });

  // ---- Data ----
  function load() {
    return fetch('/api/map/markers', { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (res) {
        var ct = res.headers.get('content-type') || '';
        if (!res.ok || ct.indexOf('json') < 0) throw new Error('Kunne ikke hente kartdata.');
        return res.json();
      })
      .then(function (data) {
        all = data;
        refreshTypeOptions();
        renderTypeLegend();
        render();

        if (firstLoad) {
          firstLoad = false;
          var q = new URLSearchParams(window.location.search);
          var lat = parseFloat(q.get('lat')), lng = parseFloat(q.get('lng')), z = parseInt(q.get('z'), 10);
          if (!isNaN(lat) && !isNaN(lng)) {
            map.setView([lat, lng], isNaN(z) ? 14 : z);
          } else if (all.length > 0) {
            map.fitBounds(all.map(function (m) { return [m.lat, m.lng]; }), { padding: [60, 60], maxZoom: 12 });
          }
        }
      })
      .catch(function (err) { statusEl.textContent = err.message; });
  }

  FM.reload = load;
  load();
  // Hold kartet oppdatert uten manuell reload (felles situasjonsforståelse)
  setInterval(function () { if (!document.hidden) load(); }, 30000);
})();
