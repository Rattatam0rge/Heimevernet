/* Paneler over kartet (registrer behov/ressurs, sett organisasjonens posisjon).
 * Stedet velges i det samme hovedkartet. Kun ett panel er åpent om gangen. */
(function () {
  'use strict';

  var panels = Array.prototype.slice.call(document.querySelectorAll('.reg-panel'));
  if (panels.length === 0 || !window.FM || !FM.map) return;

  var map = FM.map;
  var wrap = document.querySelector('.map-wrap');
  var mapEl = document.getElementById('map');
  var registry = {};
  var lastOpener = null;

  function pad(n) { return String(n).padStart(2, '0'); }
  function localInput(d) {
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function initPanel(panel) {
    var form = panel.querySelector('form');
    var closeBtn = panel.querySelector('.reg-close');
    var submitBtn = panel.querySelector('.reg-submit');
    var latIn = panel.querySelector('[name="Latitude"]');
    var lngIn = panel.querySelector('[name="Longitude"]');
    var locText = panel.querySelector('.reg-loc-text');
    var generalError = panel.querySelector('.reg-general-error');
    var submitLabel = submitBtn.textContent;
    var pin = null;
    var isOpen = false;

    function setDefaults() {
      var deadline = form.querySelector('[name="Deadline"]');
      var from = form.querySelector('[name="AvailableFrom"]');
      if (deadline && !deadline.value) deadline.value = localInput(new Date(Date.now() + 24 * 3600 * 1000));
      if (from && !from.value) from.value = localInput(new Date());
    }

    // ---- Valg av sted i hovedkartet ----
    function showError(field, msg) {
      var el = form.querySelector('[data-error-for="' + field + '"]');
      if (el) el.textContent = msg;
    }

    function setPoint(lat, lng, pan) {
      latIn.value = lat.toFixed(6);
      lngIn.value = lng.toFixed(6);
      locText.textContent = 'Valgt posisjon: ' + lat.toFixed(5) + ', ' + lng.toFixed(5);
      locText.classList.add('has-point');
      showError('Latitude', '');

      if (!pin) {
        pin = L.marker([lat, lng], { icon: FM.icon('pick'), draggable: true, keyboard: true }).addTo(map);
        pin.on('dragend', function () { var p = pin.getLatLng(); setPoint(p.lat, p.lng, false); });
      } else {
        pin.setLatLng([lat, lng]);
      }
      if (pan) map.setView([lat, lng], Math.max(map.getZoom(), 13));
    }

    function onMapClick(e) { setPoint(e.latlng.lat, e.latlng.lng, false); }

    function clearPoint() {
      latIn.value = '';
      lngIn.value = '';
      locText.textContent = 'Trykk på kartet for å velge sted';
      locText.classList.remove('has-point');
      if (pin) { map.removeLayer(pin); pin = null; }
    }

    // ---- Feilvisning ----
    function clearErrors() {
      form.querySelectorAll('.field-error').forEach(function (el) { el.textContent = ''; });
      generalError.hidden = true;
      generalError.textContent = '';
    }

    function showErrors(errors) {
      var general = [];
      Object.keys(errors).forEach(function (key) {
        var msg = errors[key].join(' ');
        var field = key === 'Longitude' ? 'Latitude' : key;
        var el = form.querySelector('[data-error-for="' + field + '"]');
        if (el) el.textContent = msg; else general.push(msg);
      });
      if (general.length) {
        generalError.textContent = general.join(' ');
        generalError.hidden = false;
      }
    }

    // ---- Åpne/lukke ----
    function open() {
      Object.keys(registry).forEach(function (id) {
        if (registry[id] !== api && registry[id].isOpen()) registry[id].close(false);
      });
      isOpen = true;
      panel.hidden = false;
      wrap.classList.add('reg-open');
      mapEl.classList.add('picking');
      map.on('click', onMapClick);
      setDefaults();
      var first = form.querySelector('select, input:not([type="hidden"]):not([type="radio"])');
      if (first) first.focus();
    }

    function close(restoreFocus) {
      isOpen = false;
      panel.hidden = true;
      wrap.classList.remove('reg-open');
      mapEl.classList.remove('picking');
      map.off('click', onMapClick);
      clearErrors();
      clearPoint();
      if (restoreFocus !== false && lastOpener) lastOpener.focus();
    }

    closeBtn.addEventListener('click', function () { close(true); });
    panel.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(true); });

    panel.querySelector('.reg-mylocation').addEventListener('click', function () {
      if (!navigator.geolocation) {
        locText.textContent = 'Enheten din støtter ikke posisjon. Trykk i kartet i stedet.';
        return;
      }
      locText.textContent = 'Henter posisjon…';
      navigator.geolocation.getCurrentPosition(
        function (pos) { setPoint(pos.coords.latitude, pos.coords.longitude, true); },
        function () { locText.textContent = 'Fikk ikke tilgang til posisjonen. Trykk i kartet i stedet.'; },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    });

    // ---- Send inn ----
    function setBusy(busy) {
      submitBtn.disabled = busy;
      submitBtn.textContent = busy ? 'Lagrer…' : submitLabel;
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearErrors();

      if (!latIn.value || !lngIn.value) {
        showError('Latitude', 'Velg et sted på kartet.');
        locText.scrollIntoView({ block: 'nearest' });
        return;
      }
      if (!form.reportValidity()) return;

      setBusy(true);
      fetch(form.action, {
        method: 'POST',
        body: new FormData(form),     // inkluderer antiforgery-token fra skjemaet
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' }
      })
        .then(function (res) {
          var ct = res.headers.get('content-type') || '';
          if (ct.indexOf('json') < 0) throw new Error('Økten din kan ha utløpt. Last siden på nytt og logg inn.');
          return res.json().then(function (data) { return { ok: res.ok, data: data }; });
        })
        .then(function (r) {
          if (r.ok && r.data.success) {
            var lat = parseFloat(latIn.value), lng = parseFloat(lngIn.value);
            form.reset();
            close(false);
            FM.toast(r.data.message, 'success', r.data.url, r.data.linkText);
            FM.reload();
            map.setView([lat, lng], Math.max(map.getZoom(), 13));
          } else {
            showErrors(r.data.errors || {});
          }
        })
        .catch(function (err) { FM.toast(err.message, 'danger'); })
        .finally(function () { setBusy(false); });
    });

    var api = { open: open, close: close, isOpen: function () { return isOpen; } };
    registry[panel.id] = api;
  }

  panels.forEach(initPanel);

  // Knapper med data-open-panel åpner tilhørende panel
  document.querySelectorAll('[data-open-panel]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var target = registry[btn.getAttribute('data-open-panel')];
      if (!target) return;
      lastOpener = btn;
      target.open();
    });
  });

  // Fra "+ Registrer"-knappene på listesidene: /?register=1
  if (new URLSearchParams(window.location.search).get('register') === '1' && registry['register-panel']) {
    registry['register-panel'].open();
  }
})();
