namespace FeedbackMap.Models;

public class Assignment
{
    public int Id { get; set; }

    public int NeedId { get; set; }
    public Need Need { get; set; } = null!;

    public int ResourceId { get; set; }
    public Resource Resource { get; set; } = null!;

    public DateTime AssignedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UnassignedAt { get; set; }
    public MatchStatus MatchStatus { get; set; } = MatchStatus.Proposed;

    public Notification? Notification { get; set; }
}
