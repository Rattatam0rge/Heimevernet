namespace FeedbackMap.Models;

/// <summary>Typer fra caset. Utvides senere til egne kategorier (case: "Kategorier for ressurstyper").</summary>
public static class Catalog
{
    public static readonly string[] NeedTypes =
    {
        "Transport", "Droneobservasjon", "Strøm/aggregat", "Snørydding", "Sand/grus",
        "Maskiner", "Evakuering", "Samband", "Mannskap", "Lokaler", "Annet"
    };

    public static readonly string[] ResourceTypes =
    {
        "Drone og droneoperatør", "ATV", "Traktor", "Gravemaskin", "Hjullaster", "Skogsmaskin",
        "Snøskuter", "Lastebil", "Sand/grus", "Aggregat", "Lokaler", "Sambandsutstyr", "Båt",
        "Mannskap/frivillige", "Annet"
    };
}
