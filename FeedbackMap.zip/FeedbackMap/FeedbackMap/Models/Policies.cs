namespace FeedbackMap.Models;

public static class Policies
{
    /// <summary>Innlogget OG fullført 2FA (amr-claim "mfa").</summary>
    public const string RequireMfa = "RequireMfa";
}
