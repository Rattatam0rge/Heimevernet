using System.ComponentModel.DataAnnotations;

namespace FeedbackMap.Models;

public class ResourceProviderProfile
{
    [Key] public string UserId { get; set; } = string.Empty;   // PK + FK til ApplicationUser
    public ApplicationUser User { get; set; } = null!;

    public ProviderType ProviderType { get; set; }
    [MaxLength(30)] public string? ContactPhone { get; set; }

    public ICollection<Resource> Resources { get; set; } = new List<Resource>();
}
