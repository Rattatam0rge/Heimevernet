namespace FeedbackMap.Models;

public static class Roles
{
    public const string PublicActor = "PublicActor";
    public const string ResourceProvider = "ResourceProvider";
}

/// <summary>Statusflyt fra user story #8.</summary>
public enum NeedStatus { New, UnderReview, Assigned, Resolved }

/// <summary>Kartfarger: rød = akutt, gul = planlagt.</summary>
public enum NeedPriority { Acute, Planned }

public enum ResourceStatus { Available, Unavailable }

public enum MatchStatus { Proposed, Confirmed, Completed, Cancelled }

public enum ProviderType
{
    PrivatePerson, Business, Farmer, Contractor, VoluntaryOrganisation, DroneOperator
}
