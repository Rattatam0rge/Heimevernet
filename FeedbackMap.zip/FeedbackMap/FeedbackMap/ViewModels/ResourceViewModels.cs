using System.ComponentModel.DataAnnotations;
using FeedbackMap.Models;
using FeedbackMap.Services;

namespace FeedbackMap.ViewModels;

public class ResourceCreateViewModel : IValidatableObject
{
    [Required(ErrorMessage = "Velg type ressurs."), Display(Name = "Type ressurs")]
    public string Type { get; set; } = string.Empty;

    [MaxLength(1000, ErrorMessage = "Maks 1000 tegn."), Display(Name = "Beskrivelse")]
    public string? Description { get; set; }

    [Required(ErrorMessage = "Velg et sted på kartet."), Range(-90.0, 90.0, ErrorMessage = "Ugyldig breddegrad.")]
    public decimal? Latitude { get; set; }

    [Required(ErrorMessage = "Velg et sted på kartet."), Range(-180.0, 180.0, ErrorMessage = "Ugyldig lengdegrad.")]
    public decimal? Longitude { get; set; }

    [Required(ErrorMessage = "Fra-tidspunkt må fylles ut."), Display(Name = "Tilgjengelig fra")]
    public DateTime? AvailableFrom { get; set; }

    [Display(Name = "Tilgjengelig til (valgfritt)")]
    public DateTime? AvailableTo { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!string.IsNullOrEmpty(Type) && !Catalog.ResourceTypes.Contains(Type))
            yield return new ValidationResult("Ugyldig type.", new[] { nameof(Type) });

        if (AvailableFrom.HasValue && AvailableTo.HasValue && AvailableTo < AvailableFrom)
            yield return new ValidationResult("«Til» må være etter «fra».", new[] { nameof(AvailableTo) });
    }
}

public class ResourceIndexViewModel
{
    public bool IsProvider { get; set; }
    public IReadOnlyList<ResourceListItem> Items { get; set; } = Array.Empty<ResourceListItem>();
}
