namespace FeedbackMap.ViewModels;

/// <summary>Icon: "acute" | "planned" | "resource". Kind: "need" | "resource".</summary>
public record MapMarkerDto(
    string Kind, string Icon, int Id, double Lat, double Lng,
    string Type, string Title, string Status, string When,
    string? Contact, string? Phone, string? Email, string? Url);
