# FeedbackMap – ressurs- og behovsportal for Totalforsvaret

Webapplikasjon for krisehåndtering: offentlige aktører (kommune, politi, brann, helse, Sivilforsvaret,
Heimevernet) registrerer **behov**, og innbyggere, bedrifter og frivillige registrerer **ressurser**.
Alt vises på ett kart (Leaflet + Kartverket), slik at hjelpen kan rettes dit den trengs mest.

Bygget i emnene IS-200 og IS-201 (Universitetet i Agder) i samarbeid med Kartverket og Heimevernet.

## Krav

Du trenger bare **Docker Desktop** (og Git for å hente koden). .NET SDK og MariaDB trenger du **ikke**
installere. Alt bygges og kjøres i containere.

- Docker Desktop: https://www.docker.com/products/docker-desktop/
- Git: https://git-scm.com/downloads

## Kom i gang

```bash
git clone <URL-til-repoet>
cd <mappenavn>
docker compose up --build
```

Åpne deretter **http://localhost:8080**.

**Windows-snarvei:** dobbeltklikk `start.bat`. Den sjekker at Docker kjører, starter appen og åpner
nettleseren når den er klar. Mac/Linux: `./start.sh`.

Første oppstart tar noen minutter (laster ned og bygger images). Databasen og alle tabeller opprettes
automatisk. Du trenger ingen `.env`-fil (se *Konfigurasjon* under).

## Første gangs bruk

1. Klikk **Registrer deg** og velg rolle: *Offentlig aktør* eller *Ressursleverandør*.
2. Du må sette opp **to-faktor-autentisering**. Installer en authenticator-app (Microsoft Authenticator eller
   Google Authenticator) på mobilen, skann QR-koden og skriv inn koden. **Lagre gjenopprettingskodene.**
3. Du kommer til kartet.
   - *Offentlig aktør:* «+ Registrer behov», og «Sett organisasjonens posisjon» (blå markør).
   - *Ressursleverandør:* «+ Registrer ressurs».
4. Registreringen skjer i et panel over kartet. Velg sted ved å trykke i kartet.

Tips for å teste begge roller samtidig: bruk to nettlesere, eller ett vanlig og ett privat vindu.

> **Rask utvikling uten to-faktor:** legg `REQUIRE_2FA=false` i `.env`. Da holder e-post og passord.
> Caset krever to-faktor, så la det stå på `true` (standard) ved innlevering, EXPO og sikkerhetstesting.

> Authenticator-koder avhenger av klokken. Står klokken på mobilen eller PC-en feil, avvises koden.
> Slå på automatisk tid/dato.

## Daglig bruk

| Handling | Kommando | Windows |
|---|---|---|
| Starte | `docker compose up -d` | `start.bat` |
| Stoppe (data beholdes) | `docker compose down` | `stop.bat` |
| Se logg | `docker compose logs -f web` | |
| Nullstille alt (sletter databasen) | `docker compose down -v` | `reset.bat` |
| Bygge på nytt etter kodeendring | `docker compose up --build` | `start.bat` |

## Feilsøking

| Problem | Løsning |
|---|---|
| «Docker Desktop kjører ikke» / `error during connect` | Start Docker Desktop og vent til den er klar. |
| `port is already allocated` (8080 eller 3307) | Noe annet bruker porten. Kopier `.env.example` til `.env` og endre `WEB_PORT` / `DB_PORT`. |
| Siden laster ikke rett etter oppstart | Vent 20–30 sekunder (databasen starter først) og last siden på nytt. |
| Koden fra authenticator-appen avvises | Sjekk klokken på mobil og PC. Bruk ellers en gjenopprettingskode. |
| Kontoen er låst | Låses 5 minutter etter 3 feil forsøk. Vent, eller `reset.bat`. |
| «Bruk min posisjon» virker ikke | Nettleseren tillater posisjon bare på `localhost` eller HTTPS. Trykk i kartet i stedet. |
| Kartet er grått | Maskinen trenger internett (kartfliser fra Kartverket, kartbibliotek fra unpkg). |
| Alt er rart etter oppdatering | `docker compose down -v`, deretter `docker compose up --build`. |

## Konfigurasjon

Alt har standardverdier. Vil du endre noe: `cp .env.example .env` (Windows: `copy .env.example .env`).

| Variabel | Standard | Beskrivelse |
|---|---|---|
| `WEB_PORT` | 8080 | Porten appen åpnes på |
| `DB_PORT` | 3307 | Porten databasen åpnes på lokalt (for databaseverktøy) |
| `REQUIRE_2FA` | true | `false` slår av to-faktor (kun lokal utvikling) |
| `DB_NAME`, `DB_USER` | feedbackmap | Database og bruker |
| `DB_PASSWORD`, `DB_ROOT_PASSWORD` | *(utviklingspassord)* | Bytt ved annen bruk enn lokal utvikling |

> Passordene i `docker-compose.yml` er kun utviklingsverdier. Ved ekte drift må de byttes, og
> HTTPS må settes opp foran applikasjonen.

Endrer du passord etter at databasen er opprettet, må du kjøre `docker compose down -v` først.

## Roller og tilgang

| | Offentlig aktør | Ressursleverandør |
|---|---|---|
| Registrere behov | ✔ | |
| Se alle behov og tilgjengelige ressurser | ✔ | |
| Endre status på behov (ny → vurderes → tildelt → løst) | ✔ | |
| Sette organisasjonens posisjon (blå markør) | ✔ | |
| Registrere og fjerne egne ressurser | | ✔ |
| Se egne ressurser på kartet | | ✔ |

Alle funksjoner krever innlogging med **to-faktor**.

## Kartsymboler

| Symbol | Betydning |
|---|---|
| Rød trekant | Akutt behov |
| Gul rombe | Planlagt behov |
| Grønn sirkel | Tilgjengelig ressurs |
| Blå firkant | Offentlig aktør |

Ikonet inni viser typen (traktor, lastebil, aggregat osv.). Alle markører har hvit og svart kant for kontrast.
Flyfoto kan slås på i filteret (av som standard).

## Arkitektur

ASP.NET Core MVC (.NET 10) · Entity Framework Core · MariaDB 11.4 · Docker Compose · Leaflet.

```
docker-compose.yml        web + db
Dockerfile                bygger web-applikasjonen
FeedbackMap/
  Controllers/            Account, Home, Need, Resource, Actor, MapApi (JSON til kartet)
  Services/               forretningslogikk bak interfaces (NeedService, ResourceService, ActorService)
  Data/                   ApplicationDbContext (EF Core) og Migrations/
  Models/                 entiteter (Need, Resource, Assignment, NeedStatusLog, Notification ...)
  ViewModels/             data mellom controller og view
  Views/                  Razor-views
  wwwroot/js/             kart (Leaflet), søk, registreringspanel
```

Prinsipper (fra IS-200 designrapport): separation of concerns (controller → service → data),
sikkerhet (Identity, 2FA, rollebasert tilgang, CSRF-beskyttelse, lockout) og portabilitet (Docker).

Datamodellen følger IS-201-rapporten: `ACTOR` = ASP.NET Core Identity-bruker, med profiltabellene
`PublicActor` og `ResourceProvider` (class table inheritance), og `Assignment` som koblingstabell mellom
`Need` og `Resource`. Statusen på et behov utledes fra `NeedStatusLog`.

## Eksterne tjenester og lisenser

- Kartbakgrunn: Kartverket (topografisk WMTS), åpne data
- Søk etter adresse, sted og postnummer: Kartverkets/Geonorges åpne API-er
- Flyfoto (valgfritt): Esri World Imagery
- Ikoner: Material Design Icons (Pictogrammers), Apache License 2.0
- Leaflet 1.9.4 (BSD-2), lastes fra unpkg

## Testing

*(Fylles ut når testene er gjennomført: enhetstesting, systemtesting, sikkerhetstesting og
brukervennlighetstesting. Skriv testscenarier og resultater her.)*

## Utvikling uten Docker (valgfritt)

Krever .NET SDK 10 og en kjørende MariaDB (kan startes med `docker compose up db`).

```bash
cd FeedbackMap
dotnet ef migrations add <Navn>      # ny migrasjon (krever: dotnet tool install --global dotnet-ef)
dotnet run                           # kobler til databasen på localhost:3307
```
