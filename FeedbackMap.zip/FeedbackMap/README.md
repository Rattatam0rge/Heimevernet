# BeredLink – ressurs- og behovsportal for Totalforsvaret

*Ressurser · Samarbeid · Beredskap*

Webapplikasjon for krisehåndtering: offentlige aktører (kommune, politi, brann, helse, Sivilforsvaret,
Heimevernet) registrerer **behov**, og innbyggere, bedrifter og frivillige registrerer **ressurser**
(med bilde). Alt vises på ett kart (Leaflet + Kartverket), og kriseledelsen kan tildele ressurser til behov.

Bygget i emnene IS-200 og IS-201 (Universitetet i Agder) i samarbeid med Kartverket og Heimevernet.

## Krav

Du trenger bare **Docker Desktop** (og Git for å hente koden). .NET SDK og MariaDB trenger du **ikke**
installere. Alt bygges og kjøres i containere.

- Docker Desktop: https://www.docker.com/products/docker-desktop/
- Git: https://git-scm.com/downloads

## Kom i gang

```bash
git clone <URL-til-repoet>
cd <mappenavn>
docker compose up --build
```

Åpne deretter **http://localhost:8080**.

Første oppstart tar noen minutter. Databasen og alle tabeller opprettes automatisk.
Du trenger ingen `.env`-fil (se *Konfigurasjon*).

## Første gangs bruk

1. Klikk **Registrer deg** og velg rolle: *Offentlig aktør* eller *Ressursleverandør*.
2. Sett opp **to-faktor-autentisering**: installer en authenticator-app (Microsoft/Google Authenticator),
   skann QR-koden og skriv inn koden. **Lagre gjenopprettingskodene.**
3. Du kommer til kartet.

Tips for å teste begge roller samtidig: bruk to nettlesere, eller ett vanlig og ett privat vindu.

> **Rask utvikling uten to-faktor:** legg `REQUIRE_2FA=false` i `.env`. Da holder e-post og passord.
> Caset krever to-faktor, så la det stå på `true` (standard) ved innlevering, EXPO og sikkerhetstesting.

> Authenticator-koder avhenger av klokken. Står klokken på mobilen eller PC-en feil, avvises koden.

## Funksjoner

**Kart**
- Kartbakgrunn fra Kartverket, filter (type, akutt/planlagt, ressurser, offentlige aktører), tegnforklaring som kan minimeres
- Søkefelt for adresse, sted og postnummer (Kartverkets åpne API-er)
- Symbol per type (traktor, lastebil, aggregat, båt, mannskap osv.) med hvit og svart kant for kontrast
- Ressurser som ligger tett samles i klynger, slik at kartet er lesbart også med hundrevis av ressurser
- **Radiusfilter rundt et behov:** velg et behov, og se bare ressurser innen 500 m, 1, 2, 5 eller 10 km (valgfritt bare passende typer)
- **Skriv ut ressursliste** for dagens kartutsnitt (region)
- Oppdateres automatisk hvert 30. sekund

**Offentlig aktør**
- Registrere behov i et panel over kartet (sted velges i kartet)
- Se ressurser i nærheten av et behov, sortert på avstand, og **tildele** dem. Ressurser kan ikke dobbelttildeles
- Statusflyt: ny → vurderes → tildelt → løst, med historikk og tidsstempel
- Avbryte tildeling, sette organisasjonens posisjon (blå markør), aktivitetslogg

**Ressursleverandør**
- Registrere ressurs med **bilde**, sted og tilgjengelighet. Bildet vises i kartpopup og lister
- Se og fjerne egne ressurser
- **Varsler** (med teller i menyen) når en ressurs tildeles eller tildelingen avbrytes

## Roller og tilgang

| | Offentlig aktør | Ressursleverandør |
|---|---|---|
| Registrere behov | ✔ | |
| Se alle behov og tilgjengelige ressurser | ✔ | |
| Tildele ressurser, endre status | ✔ | |
| Sette organisasjonens posisjon, se aktivitetslogg | ✔ | |
| Skrive ut ressursliste for en region | ✔ | |
| Registrere og fjerne egne ressurser (med bilde) | | ✔ |
| Se egne ressurser og varsler | | ✔ |

Alle funksjoner krever innlogging med **to-faktor**.

## Kartsymboler

| Form og farge | Betydning |
|---|---|
| Rød trekant | Akutt behov |
| Gul rombe | Planlagt behov |
| Grønn sirkel | Tilgjengelig ressurs |
| Blå firkant | Offentlig aktør |

Ikonet inni viser typen. Samlemarkør (grønn sirkel med tall) viser flere ressurser som ligger tett.

## Sikkerhetstiltak

| Tiltak | Beskrivelse |
|---|---|
| Autentisering | ASP.NET Core Identity, passord hashes, minst 10 tegn med store/små bokstaver og tall |
| To-faktor | TOTP (authenticator-app) kreves for all tilgang, med gjenopprettingskoder |
| Utestenging | Konto låses 5 minutter etter 3 feil (passord og kode) |
| Rate limiting | Maks 15 forsøk i minuttet per IP mot innlogging, registrering og 2FA |
| Autorisasjon | Rollebasert (`PublicActor`, `ResourceProvider`) + policy `RequireMfa`. Eierskapssjekk ved sletting og bildevisning |
| CSRF | Antiforgery-token kreves på alle POST-forespørsler |
| XSS | Brukerdata bygges inn med `textContent`/Razor-koding. Streng Content-Security-Policy (kun egne skript) |
| Sikkerhetshoder | CSP, `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy` |
| Filopplasting | Filtype avgjøres av innholdet (JPEG/PNG/WebP), maks 5 MB, tilfeldig filnavn, lagres utenfor `wwwroot`, vises kun til innloggede |
| Personvern | Bilder skaleres i nettleseren, og EXIF (f.eks. GPS-posisjon) fjernes før opplasting |
| Dataintegritet | Unik indeks hindrer to aktive tildelinger av samme ressurs, også ved samtidige forespørsler |
| Sporbarhet | Aktivitetslogg for innlogging, registrering, tildeling, statusendringer og sletting |
| Hemmeligheter | Passord og tilkobling ligger i miljøvariabler/`.env`, ikke i koden |
| Lokale biblioteker | Leaflet og klyngebibliotek hostes lokalt (ingen eksterne skript) |

> Passordene i `docker-compose.yml` er kun utviklingsverdier. Ved ekte drift må de byttes, og
> HTTPS må settes opp foran applikasjonen (reverse proxy).

## Testing

### Automatiske tester (enhetstester)

```bash
dotnet test FeedbackMap.Tests/FeedbackMap.Tests.csproj
```

Krever .NET SDK 10. Testene kjører mot en in-memory database og dekker blant annet:

| Område | Eksempler |
|---|---|
| Statusflyt | ny → vurderes → tildelt → løst, ugyldige overganger avvises, historikk loggføres |
| Tildeling | Tildeling setter status og oppretter varsel, ingen dobbelttildeling, avbrutt tildeling frigjør ressurs |
| Matching | Radius, sortering på avstand, passende typer, ressurser som allerede er tildelt vises ikke |
| Ressurser | Sletting uten historikk/med historikk/mens tildelt, kun egne ressurser, region-filter |
| Bilder | Kun JPEG/PNG/WebP etter innhold (ikke filnavn), størrelsesgrense, stiangrep (path traversal) |
| Varsler og logg | Kun eier kan lese og markere varsler, viktige handlinger skrives til loggen |
| Geografi | Avstandsberegning (haversine) |

Testene kjøres også automatisk på GitHub (`.github/workflows/ci.yml`).

### Manuelle testscenarier

Fyll ut kolonnen *Resultat* (OK / feil + kommentar) når scenariene er utført.

| # | Type | Scenario | Forventet | Resultat |
|---|---|---|---|---|
| 1 | System | Registrer offentlig aktør og sett opp 2FA | QR-kode vises, kode godtas, gjenopprettingskoder vises, kart åpnes | |
| 2 | System | Registrer ressursleverandør | Kart åpnes etter 2FA | |
| 3 | System | Offentlig aktør registrerer behov via panel på kartet | Behovet vises som rød trekant og i listen | |
| 4 | System | Leverandør registrerer ressurs med bilde | Grønn markør med ikon, bildet vises i popup og liste | |
| 5 | System | Velg et behov og bruk radiusfilter (500 m, 1 km …) | Kun ressurser innen radius vises, antall oppgis | |
| 6 | System | Tildel ressurs fra behovssiden | Status blir «Tildelt», leverandør får varsel | |
| 7 | System | Forsøk å tildele samme ressurs til et annet behov | Avvises med melding | |
| 8 | System | Avbryt tildeling | Status tilbake til «Vurderes», leverandør varsles, ressursen er ledig | |
| 9 | System | Sett behov til «Løst» | Tildelinger fullføres, ressurser frigjøres | |
| 10 | System | Skriv ut ressursliste for kartutsnitt | Utskriftsvennlig liste med riktige ressurser | |
| 11 | Sikkerhet | 3 feil kode/passord på rad | Konto låses i 5 minutter | |
| 12 | Sikkerhet | Åpne `/Need`, `/Audit` og `/api/map/markers` uten innlogging | Sendes til innlogging | |
| 13 | Sikkerhet | Leverandør åpner `/Need` eller `/Audit` | Ingen tilgang | |
| 14 | Sikkerhet | Leverandør prøver å slette andres ressurs (endre id) | Avvises | |
| 15 | Sikkerhet | Last opp en `.txt`-fil omdøpt til `.jpg` | Avvises, ingen fil lagres | |
| 16 | Sikkerhet | Send skjema uten antiforgery-token | 400-feil | |
| 17 | Sikkerhet | Skriv `<script>alert(1)</script>` i beskrivelse/kontaktpunkt | Vises som tekst, ingenting kjøres | |
| 18 | Sikkerhet | Mange innloggingsforsøk raskt etter hverandre | Blir stoppet (429) | |
| 19 | Brukervennlighet | Registrer behov på mobil | Panel nederst, store knapper, sted kan velges | |
| 20 | Brukervennlighet | Søk på adresse, sted og postnummer | Kartet flytter seg til treffet | |
| 21 | Brukervennlighet | Kontrast: markører på kart med mange symboler | Forskjell på type og kategori er tydelig | |

## Daglig bruk

| Handling | Kommando |
|---|---|
| Starte (første gang og etter kodeendring) | `docker compose up --build` |
| Starte i bakgrunnen | `docker compose up -d` |
| Stoppe (data beholdes) | `docker compose down` |
| Se logg | `docker compose logs -f web` |
| Nullstille alt (sletter database og bilder) | `docker compose down -v` |

## Feilsøking

| Problem | Løsning |
|---|---|
| «Docker Desktop kjører ikke» / `error during connect` | Start Docker Desktop og vent til den er klar. |
| `port is already allocated` (8080 eller 3307) | Kopier `.env.example` til `.env` og endre `WEB_PORT` / `DB_PORT`. |
| Siden laster ikke rett etter oppstart | Vent 20–30 sekunder (databasen starter først) og last siden på nytt. |
| Koden fra authenticator-appen avvises | Sjekk klokken på mobil og PC. Bruk ellers en gjenopprettingskode. |
| Kontoen er låst | Låses 5 minutter etter 3 feil forsøk. Vent, eller nullstill med `docker compose down -v`. |
| Bildet blir ikke lastet opp | Bruk JPEG, PNG eller WebP under 5 MB. |
| «Bruk min posisjon» virker ikke | Nettleseren tillater posisjon bare på `localhost` eller HTTPS. Trykk i kartet i stedet. |
| Kartet er grått | Maskinen trenger internett (kartfliser fra Kartverket). |
| 429 «Too Many Requests» | For mange innloggingsforsøk. Vent ett minutt. |
| Alt er rart etter oppdatering | `docker compose down -v`, deretter `docker compose up --build`. |

## Konfigurasjon

Alt har standardverdier. Vil du endre noe: `cp .env.example .env` (Windows: `copy .env.example .env`).

| Variabel | Standard | Beskrivelse |
|---|---|---|
| `WEB_PORT` | 8080 | Porten appen åpnes på |
| `DB_PORT` | 3307 | Porten databasen åpnes på lokalt (for databaseverktøy) |
| `REQUIRE_2FA` | true | `false` slår av to-faktor (kun lokal utvikling) |
| `DB_NAME`, `DB_USER` | feedbackmap | Database og bruker |
| `DB_PASSWORD`, `DB_ROOT_PASSWORD` | *(utviklingspassord)* | Bytt ved annen bruk enn lokal utvikling |

Endrer du passord etter at databasen er opprettet, må du kjøre `docker compose down -v` først.

## Arkitektur

ASP.NET Core MVC (.NET 10) · Entity Framework Core · MariaDB 11.4 · Docker Compose · Leaflet.

```
docker-compose.yml          web + db (+ volum for databasen og bilder)
Dockerfile                  bygger web-applikasjonen
FeedbackMap/                web-prosjektet
  Controllers/              Account, Home, Need, Resource, Actor, Media, Notification, Audit, MapApi (JSON)
  Services/                 forretningslogikk bak interfaces (Need, Resource, Assignment, Notification, Audit, ImageStorage ...)
  Data/                     ApplicationDbContext (EF Core) og Migrations/
  Models/                   entiteter (Need, Resource, Assignment, NeedStatusLog, Notification, AuditLog ...)
  ViewModels/  Views/       data til og visning i Razor
  wwwroot/js/               kart, søk, registreringspanel, startside
  wwwroot/lib/leaflet/      Leaflet og klyngebibliotek (lokalt)
FeedbackMap.Tests/          enhetstester (xUnit)
.github/workflows/ci.yml    bygg og test på GitHub
```

Prinsipper (fra IS-200 designrapport): separation of concerns (controller → service → data),
sikkerhet (Identity, 2FA, rollebasert tilgang, CSRF, lockout), testbarhet og portabilitet (Docker).

Datamodellen følger IS-201-rapporten: `ACTOR` = ASP.NET Core Identity-bruker, med profiltabellene
`PublicActor` og `ResourceProvider` (class table inheritance), og `Assignment` som koblingstabell mellom
`Need` og `Resource`. Statusen på et behov utledes fra `NeedStatusLog`.

## Eksterne tjenester og lisenser

- Kartbakgrunn: Kartverket (topografisk WMTS), åpne data
- Søk etter adresse, sted og postnummer: Kartverkets/Geonorges åpne API-er
- Ikoner: Material Design Icons (Pictogrammers), Apache License 2.0
- Leaflet 1.9.4 (BSD-2) og Leaflet.markercluster 1.5.3 (MIT), hostet lokalt

## Utvikling uten Docker (valgfritt)

Krever .NET SDK 10 og en kjørende MariaDB (kan startes med `docker compose up db`).

```bash
cd FeedbackMap
dotnet ef migrations add <Navn>      # ny migrasjon (krever: dotnet tool install --global dotnet-ef)
dotnet run                           # kobler til databasen på localhost:3307
```
