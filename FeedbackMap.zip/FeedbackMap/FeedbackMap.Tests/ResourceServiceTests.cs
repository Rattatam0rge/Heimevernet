using FeedbackMap.Models;
using FeedbackMap.Services;

namespace FeedbackMap.Tests;

public class ResourceServiceTests
{
    [Fact]
    public async Task Remove_WithoutAssignments_DeletesRow()
    {
        using var f = new Fixture();
        var id = await f.ResourceAsync();

        var result = await f.Resources.RemoveAsync(Fixture.Provider, id);

        Assert.True(result.Success);
        Assert.Empty(f.Db.Resources);
    }

    [Fact]
    public async Task Remove_WithHistory_DeactivatesInsteadOfDeleting()
    {
        using var f = new Fixture();
        var need = await f.NeedAsync();
        var id = await f.ResourceAsync();
        await f.Assignments.AssignAsync(need, id, Fixture.Actor);
        await f.Assignments.UnassignAsync(f.Db.Assignments.Single().Id, Fixture.Actor);

        var result = await f.Resources.RemoveAsync(Fixture.Provider, id);

        Assert.True(result.Success);
        var resource = Assert.Single(f.Db.Resources);
        Assert.False(resource.IsActive);
        Assert.Empty(await f.Resources.ListForProviderAsync(Fixture.Provider));   // vises ikke lenger i listen
        Assert.Single(f.Db.Assignments);                                          // historikken er beholdt
    }

    [Fact]
    public async Task Remove_WhileAssigned_IsRejected()
    {
        using var f = new Fixture();
        var need = await f.NeedAsync();
        var id = await f.ResourceAsync();
        await f.Assignments.AssignAsync(need, id, Fixture.Actor);

        var result = await f.Resources.RemoveAsync(Fixture.Provider, id);

        Assert.False(result.Success);
        Assert.True(Assert.Single(f.Db.Resources).IsActive);
    }

    [Fact]
    public async Task Remove_OthersResource_IsForbidden()
    {
        using var f = new Fixture();
        var id = await f.ResourceAsync(provider: Fixture.Provider);

        var result = await f.Resources.RemoveAsync(Fixture.Provider2, id);

        Assert.False(result.Success);
        Assert.True(result.Forbidden);
        Assert.Single(f.Db.Resources);
    }

    [Fact]
    public async Task ListForProvider_ShowsOnlyOwnResources()
    {
        using var f = new Fixture();
        await f.ResourceAsync(provider: Fixture.Provider);
        await f.ResourceAsync(provider: Fixture.Provider2);

        var own = await f.Resources.ListForProviderAsync(Fixture.Provider);

        Assert.Single(own);
    }

    [Fact]
    public async Task ListAvailable_ExcludesAssignedAndExpired()
    {
        using var f = new Fixture();
        var need = await f.NeedAsync();
        var assigned = await f.ResourceAsync();
        await f.ResourceAsync(availableTo: DateTime.UtcNow.AddMinutes(-1));
        var free = await f.ResourceAsync();
        await f.Assignments.AssignAsync(need, assigned, Fixture.Actor);

        var available = await f.Resources.ListAvailableAsync();

        Assert.Equal(free, Assert.Single(available).Id);
    }

    [Fact]
    public async Task ListInBounds_ReturnsOnlyResourcesInsideRegion()
    {
        using var f = new Fixture();
        var inside = await f.ResourceAsync(lat: 58.15m, lng: 8.00m);
        await f.ResourceAsync(lat: 63.43m, lng: 10.39m);   // Trondheim

        var result = await f.Resources.ListInBoundsAsync(58.0m, 58.3m, 7.8m, 8.2m, type: null);

        Assert.Equal(inside, Assert.Single(result).Id);
    }

    [Fact]
    public async Task GetImage_ReturnsNull_WhenNoImage()
    {
        using var f = new Fixture();
        var id = await f.ResourceAsync();

        Assert.Null(await f.Resources.GetImageAsync(id));
    }
}
